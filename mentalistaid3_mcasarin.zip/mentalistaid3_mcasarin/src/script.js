// sorteio aleatorio de numeros inteiros entre 0 e 10 - math.random sortei de 0 a 1
var numeroSecreto = parseInt(Math.random() * 11);
var elementoResultado = document.getElementById("resultado");
var tentativas = 0;
function Chutar() {
  if (tentativas <= 3) {
    // pegar valor do input passando para numero inteiro
    var chute = parseInt(document.getElementById("valor").value);
    // console.log(chute);
    if (chute == numeroSecreto) {
      elementoResultado.innerHTML = "ACERTOU!!!";
      tentativa = 0;
      document.getElementById("reload").style.display = "block";
      document.getElementById("valor").disabled = "true";
    } else if (chute > 10 || chute < 0) {
      tentativas = tentativas + 1;
      console.log(tentativas);
      elementoResultado.innerHTML =
        "Você deve digitar um número de 0 a 10<br>Você ainda tem " +
        (5 - tentativas) +
        " tentativa(s)";
    } else {
      var msgerro = "";
      if (chute < numeroSecreto) {
        tentativas = tentativas + 1;
        msgerro =
          "O número secreto é maior que  seu chute.<br>Você ainda tem " +
          (5 - tentativas) +
          " tentativa(s)";
      } else {
        tentativas = tentativas + 1;
        msgerro =
          "O número secreto é menor que  seu chute.<br>Você ainda tem " +
          (5 - tentativas) +
          " tentativa(s)";
      }
      elementoResultado.innerHTML = "Errou... " + msgerro;
    }
  } else {
    elementoResultado.innerHTML = "Você esgotou suas tentativas";
    document.getElementById("reload").style.display = "block";
    document.getElementById("valor").disabled = "true";
  }
}
