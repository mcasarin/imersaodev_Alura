var nome = "Marcio"
var notaDoPrimeiroBimestre = 9
var notaDoSegundoBimestre = 7
var notaDoTerceiroBimestre = 6
var notaDoQuartoBimestre = 7
var notaParcial = (notaDoPrimeiroBimestre + notaDoSegundoBimestre + notaDoTerceiroBimestre + notaDoQuartoBimestre)
var notaFinal = notaParcial / 4
// toFixed para arredondamento de casas decimais
var notaFixada = notaFinal.toFixed(1)
console.log("Bem-vindo! " + nome)
// console.log(notaFixada)
// Desafio: duas linhas com variaveis para executar o mesmo resultado; alterar fundo/imagem; criar um conversos de medidas; mostrar na tela usuário; executar todas as operações em uma linha unica
if (notaFixada < 7) {  document.getElementById("aprovacao").innerHTML = "REPROVADO, sua nota foi: " + notaFixada;
} else {  document.getElementById("aprovacao").innerHTML = "APROVADO, sua nota foi: " + notaFixada;
}

console.log(((notaDoPrimeiroBimestre+notaDoSegundoBimestre+notaDoTerceiroBimestre+notaDoQuartoBimestre)/4).toFixed(1))

var nota1bim = document.getElementById("nota1bim");
var nota2bim = document.getElementById("nota2bim");
var nota3bim = document.getElementById("nota3bim");
var nota4bim = document.getElementById("nota4bim");
var calcular = document.getElementById("calcular");
var result = document.getElementById("result");
var mensagem = document.getElementById("mensagem");

calcular.addEventListener("click",function (event){
  var nota1 = nota1bim.valueAsNumber || 0;
  var nota2 = nota2bim.valueAsNumber || 0;
  var nota3 = nota3bim.valueAsNumber || 0;
  var nota4 = nota4bim.valueAsNumber || 0;
  result.value = (nota1 + nota2 + nota3 + nota4)/4;
  
  if(result.value < 7){     document.getElementById("mensagem").innerHTML = "REPROVADO, a média das notas é: " + result.value;
  } else { document.getElementById("mensagem").innerHTML = "APROVADO, a média das notas é: " + result.value;
  }
});