function Converter() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  // parseFloat converte string em number
  var valorNumerico = parseFloat(valor);
  // console.log(valorNumerico);
  // Conversão Dolar
  var valorReal = valorNumerico * 5;
  // console.log(valorReal);
  var valorConvertido = document.getElementById("valorConvertido");
  var valorImpresso = "O resultado em real é R$ " + valorReal.toFixed(2);
  valorConvertido.innerHTML = valorImpresso;
  var valorBitCoin = valorNumerico * 0.0000257;
  var valorConvertidoBitCoin = document.getElementById(
    "valorConvertidoBitCoin"
  );
  var valorImpressoBC = "O resultado em bitcoin é " + valorBitCoin + " BTC";
  valorConvertidoBitCoin.innerHTML = valorImpressoBC;
}
// Desafio criar outro botão de conversão para outra moeda; conversor de km para anos-luz; conversor de temperatura; conversor de moeda para um novo elemento com valor bitcoin
function ConverterEuro() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorNumerico = parseFloat(valor);
  // console.log(valorNumerico);
  // Conversão Dolar
  var valorEuro = valorNumerico * 0.92;
  // console.log(valorReal);
  var valorConvertido = document.getElementById("valorConvertido");
  var valorImpresso = "O resultado em Euro é  &euro; " + valorEuro.toFixed(2);
  valorConvertido.innerHTML = valorImpresso;
  var valorBitCoin = valorNumerico * 0.0000257;
  var valorConvertidoBitCoin = document.getElementById(
    "valorConvertidoBitCoin"
  );
  var valorImpressoBC = "O resultado em bitcoin é " + valorBitCoin + " BTC";
  valorConvertidoBitCoin.innerHTML = valorImpressoBC;
}

// Conversão conforme digitação
var kilometros = document.getElementById("distancia");
var anosLuzElemento = document.getElementById("anosluzConvertido");
kilometros.addEventListener("keyup", ConverterKMLuz);
function ConverterKMLuz() {
  var kilometrosValor = eval(this.value);
  var valorAnoLuz = kilometrosValor * 0.0000000000001057;
  var anoLuzImpresso =
    "O resultado da distância em anos-luz é: " + valorAnoLuz + "ly";
  anosLuzElemento.innerHTML = anoLuzImpresso;
}

// Converter Graus
var temperatura = document.getElementById("temperatura");
var grausDe = document.getElementById("grausDe");
var grausPara = document.getElementById("grausPara");
var temperaturaConv = document.getElementById("temperaturaConv");
// console.log(temperatura.value);
function converterGraus() {
  if (grausDe.value == "c") {
    if (grausPara.value == "f") {
      var convertido = parseFloat(temperatura.value) * 1.8 + 32;
      temperaturaConv.innerHTML = convertido;
    } else if (grausPara.value == "k") {
      var convertido = parseFloat(temperatura.value) + 273;
      temperaturaConv.innerHTML = convertido;
    } else {
      var erro = "Não é possível converter para a mesma unidade";
      temperaturaConv.innerHTML = erro;
    }
  } else if (grausDe.value == "f") {
    if (grausPara.value == "c") {
      var convertido = (parseFloat(temperatura.value) - 32) / 1.8;
      temperaturaConv.innerHTML = convertido;
    } else if (grausPara.value == "k") {
      var convertido = (parseFloat(temperatura.value) - 32) / 1.8 + 273;
      temperaturaConv.innerHTML = convertido;
    } else {
      var erro = "Não é possível converter para a mesma unidade";
      temperaturaConv.innerHTML = erro;
    }
  } else if (grausDe.value == "k") {
    if (grausPara.value == "c") {
      var convertido = parseFloat(temperatura.value) - 273;
      temperaturaConv.innerHTML = convertido;
    } else if (grausPara.value == "f") {
      var convertido = 1.8 * (parseFloat(temperatura.value) - 273) + 32;
      temperaturaConv.innerHTML = convertido;
    } else {
      var erro = "Não é possível converter para a mesma unidade";
      temperaturaConv.innerHTML = erro;
    }
  }
}
